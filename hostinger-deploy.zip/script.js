// ===== SARFARAZ AHMAD WATERPROOFING - OPTIMIZED PRODUCTION SCRIPT =====

document.addEventListener('DOMContentLoaded', () => {

    // 1. Preloader Teardown
    const preloader = document.getElementById('preloader');
    const dismissPreloader = () => {
        if (!preloader) return;
        preloader.style.opacity = '0';
        preloader.style.pointerEvents = 'none';
        setTimeout(() => { preloader.style.display = 'none'; }, 500);
    };

    if (preloader) {
        if (document.readyState === 'complete') {
            setTimeout(dismissPreloader, 200);
        } else {
            window.addEventListener('load', () => setTimeout(dismissPreloader, 300), { once: true });
            setTimeout(dismissPreloader, 2000); // Safety fallback
        }
    }

    // 2. Responsive Mobile Navigation Drawer
    const hamburger = document.getElementById('hamburger');
    const mobileMenu = document.getElementById('mobileMenu');
    const menuIcon = document.getElementById('menuIcon');

    if (hamburger && mobileMenu) {
        const toggleMenu = (open) => {
            const isClosing = typeof open === 'boolean' ? !open : !mobileMenu.classList.contains('hidden');
            mobileMenu.classList.toggle('hidden', isClosing);
            if (menuIcon) {
                menuIcon.classList.toggle('fa-bars', isClosing);
                menuIcon.classList.toggle('fa-xmark', !isClosing);
            }
        };

        hamburger.addEventListener('click', () => toggleMenu());
        mobileMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => toggleMenu(false)));

        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !mobileMenu.contains(e.target)) {
                toggleMenu(false);
            }
        });
    }

    // 3. Consolidated Throttled Scroll Manager (Header, Nav Link, Counters, Scroll-Top)
    const header = document.getElementById('header');
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('#desktopNav a');
    const scrollTopBtn = document.getElementById('scrollTop');
    const counters = document.querySelectorAll('.stat-number');
    const heroStats = document.querySelector('.stat-number');
    let hasAnimatedCounters = false;

    const animateCounters = () => {
        counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target') || '0', 10);
            const duration = 1600;
            const startTime = performance.now();

            const updateCount = (currentTime) => {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const easeProgress = 1 - Math.pow(1 - progress, 3);
                counter.textContent = Math.floor(easeProgress * target);

                if (progress < 1) {
                    requestAnimationFrame(updateCount);
                } else {
                    counter.textContent = target;
                }
            };
            requestAnimationFrame(updateCount);
        });
    };

    const onScroll = () => {
        const scrollY = window.scrollY;

        // Sticky Header styling
        if (header) {
            header.classList.toggle('shadow-lg', scrollY > 80);
            header.classList.toggle('bg-[#1a1a2e]/98', scrollY > 80);
        }

        // Active Navigation link
        const scrollPos = scrollY + 180;
        sections.forEach(section => {
            const top = section.offsetTop;
            const height = section.offsetHeight;
            if (scrollPos >= top && scrollPos < top + height) {
                const id = section.getAttribute('id');
                navLinks.forEach(link => {
                    const isActive = link.getAttribute('href') === `#${id}`;
                    link.classList.toggle('text-[#ff6600]', isActive);
                    link.classList.toggle('bg-white/10', isActive);
                });
            }
        });

        // Trigger Stats Counter once in viewport
        if (!hasAnimatedCounters && heroStats) {
            const rect = heroStats.getBoundingClientRect();
            if (rect.top <= window.innerHeight && rect.bottom >= 0) {
                hasAnimatedCounters = true;
                animateCounters();
            }
        }

        // Scroll-to-Top Button visibility
        if (scrollTopBtn) {
            const showScroll = scrollY > 400;
            scrollTopBtn.classList.toggle('hidden', !showScroll);
            scrollTopBtn.classList.toggle('flex', showScroll);
        }
    };

    let scrollTicking = false;
    window.addEventListener('scroll', () => {
        if (!scrollTicking) {
            requestAnimationFrame(() => {
                onScroll();
                scrollTicking = false;
            });
            scrollTicking = true;
        }
    }, { passive: true });
    onScroll(); // Initial check on load

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    }

    // 4. Testimonials Slider with Auto-Slide & Hover Pause
    const slides = document.querySelectorAll('.testimonial-slide');
    const dots = document.querySelectorAll('.testi-dot');
    let currentSlide = 0;
    let autoSlideTimer;

    const showSlide = (index) => {
        if (!slides.length) return;
        slides.forEach((slide, i) => {
            const active = i === index;
            slide.classList.toggle('hidden', !active);
            slide.classList.toggle('active', active);
        });
        dots.forEach((dot, i) => {
            const active = i === index;
            const pill = dot.querySelector('.testi-pill') || dot;
            pill.classList.toggle('bg-[#0056b3]', active);
            pill.classList.toggle('w-6', active);
            pill.classList.toggle('bg-slate-300', !active);
            pill.classList.toggle('w-3', !active);
            dot.setAttribute('aria-selected', active ? 'true' : 'false');
        });
        currentSlide = index;
    };

    const startAutoSlide = () => {
        if (slides.length <= 1) return;
        clearInterval(autoSlideTimer);
        autoSlideTimer = setInterval(() => {
            showSlide((currentSlide + 1) % slides.length);
        }, 4500);
    };

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            showSlide(index);
            startAutoSlide();
        });
    });

    if (slides.length > 0) {
        showSlide(0);
        startAutoSlide();
        const testimonialSection = document.getElementById('testimonials');
        if (testimonialSection) {
            testimonialSection.addEventListener('mouseenter', () => clearInterval(autoSlideTimer));
            testimonialSection.addEventListener('mouseleave', () => startAutoSlide());
        }
    }

    // 5. Interactive Accessible FAQ Accordion
    const faqCards = document.querySelectorAll('.faq-card');
    faqCards.forEach(card => {
        const btn = card.querySelector('.faq-btn');
        const body = card.querySelector('.faq-body');
        const icon = btn ? btn.querySelector('i') : null;

        if (btn && body) {
            btn.addEventListener('click', () => {
                const isOpen = !body.classList.contains('hidden');

                // Close all cards
                faqCards.forEach(otherCard => {
                    const otherBody = otherCard.querySelector('.faq-body');
                    const otherBtn = otherCard.querySelector('.faq-btn');
                    const otherIcon = otherBtn ? otherBtn.querySelector('i') : null;
                    if (otherBody) otherBody.classList.add('hidden');
                    if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
                    if (otherIcon) otherIcon.style.transform = 'rotate(0deg)';
                });

                // Open clicked if was closed
                if (!isOpen) {
                    body.classList.remove('hidden');
                    btn.setAttribute('aria-expanded', 'true');
                    if (icon) icon.style.transform = 'rotate(180deg)';
                }
            });
        }
    });

    // 6. Contact Form Validation with WhatsApp Redirection
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        const showError = (input, msg) => {
            input.classList.add('border-red-500', 'bg-red-50/30');
            input.setAttribute('aria-invalid', 'true');
            const errSpan = input.parentElement.querySelector('.error-msg');
            if (errSpan) errSpan.textContent = msg;

            input.addEventListener('input', () => {
                input.classList.remove('border-red-500', 'bg-red-50/30');
                input.removeAttribute('aria-invalid');
                if (errSpan) errSpan.textContent = '';
            }, { once: true });
        };

        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            contactForm.querySelectorAll('.error-msg').forEach(msg => msg.textContent = '');

            const name = contactForm.querySelector('#name');
            const phone = contactForm.querySelector('#phone');
            const email = contactForm.querySelector('#email');
            const service = contactForm.querySelector('#service');
            const message = contactForm.querySelector('#message');

            let isValid = true;
            if (!name.value.trim() || name.value.trim().length < 2) {
                showError(name, 'Please enter your valid name');
                isValid = false;
            }

            const cleanPhone = phone.value.replace(/\D/g, '');
            if (!cleanPhone || cleanPhone.length < 10) {
                showError(phone, 'Please enter a valid 10-digit mobile number');
                isValid = false;
            }

            if (!service.value) {
                showError(service, 'Please select a waterproofing service');
                isValid = false;
            }

            if (!message.value.trim() || message.value.trim().length < 5) {
                showError(message, 'Please briefly describe your requirement');
                isValid = false;
            }

            if (isValid) {
                const whatsappText = `*Inquiry for Sarfaraz Ahmad Waterproofing*%0A%0A` +
                    `*Name:* ${encodeURIComponent(name.value.trim())}%0A` +
                    `*Phone:* ${encodeURIComponent(cleanPhone)}%0A` +
                    (email.value.trim() ? `*Email:* ${encodeURIComponent(email.value.trim())}%0A` : '') +
                    `*Service:* ${encodeURIComponent(service.value)}%0A` +
                    `*Details:* ${encodeURIComponent(message.value.trim())}%0A%0A` +
                    `_Sent via website inspection form_`;

                const targetUrl = `https://wa.me/917743054865?text=${whatsappText}`;
                const submitBtn = contactForm.querySelector('button[type="submit"]');
                const origHtml = submitBtn.innerHTML;

                submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> Redirecting to WhatsApp...';
                submitBtn.classList.replace('bg-[#0056b3]', 'bg-emerald-600');
                submitBtn.classList.replace('hover:bg-[#003d82]', 'hover:bg-emerald-700');

                setTimeout(() => {
                    window.open(targetUrl, '_blank');
                    submitBtn.innerHTML = origHtml;
                    submitBtn.classList.replace('bg-emerald-600', 'bg-[#0056b3]');
                    submitBtn.classList.replace('hover:bg-emerald-700', 'hover:bg-[#003d82]');
                    contactForm.reset();
                }, 800);
            }
        });
    }

    // 7. Smooth In-Page Anchor Navigation (with Accessible Focus Management)
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href === '#' || !href) return;
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                if (href === '#main-content' || !target.hasAttribute('tabindex')) {
                    target.setAttribute('tabindex', '-1');
                    target.focus({ preventScroll: true });
                }
            }
        });
    });

    // 8. On-Site Photo Gallery Archive Toggle
    const togglePhotosBtn = document.getElementById('togglePhotosBtn');
    const allPhotosContainer = document.getElementById('allPhotosContainer');
    const togglePhotosText = document.getElementById('togglePhotosText');
    const togglePhotosIcon = document.getElementById('togglePhotosIcon');

    if (togglePhotosBtn && allPhotosContainer) {
        togglePhotosBtn.addEventListener('click', () => {
            const isHidden = allPhotosContainer.classList.contains('hidden');
            if (isHidden) {
                allPhotosContainer.classList.remove('hidden');
                togglePhotosBtn.setAttribute('aria-expanded', 'true');
                if (togglePhotosText) togglePhotosText.textContent = 'Hide Extra Photos';
                if (togglePhotosIcon) togglePhotosIcon.classList.replace('fa-chevron-down', 'fa-chevron-up');
            } else {
                allPhotosContainer.classList.add('hidden');
                togglePhotosBtn.setAttribute('aria-expanded', 'false');
                if (togglePhotosText) togglePhotosText.textContent = 'View Full Archive (19 More On-Site Photos)';
                if (togglePhotosIcon) togglePhotosIcon.classList.replace('fa-chevron-up', 'fa-chevron-down');
                togglePhotosBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });
    }

});

