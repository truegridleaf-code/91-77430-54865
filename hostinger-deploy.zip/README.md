# Sarfaraz Ahmad Waterproofing Services — Chandigarh

Official website for **Sarfaraz Ahmad Waterproofing** — Top-rated waterproofing specialist contractor in Chandigarh, Sector 52, Kajheri, Mohali, and Panchkula.

## 🚀 Key Features
- **Mobile-First Ultra-Responsive Layout**: Built with modern Tailwind CSS utility classes and zero layout shift (CLS: 0.000).
- **All Assets in Root Directory**: Optimized flat structure for 1-click GitHub Pages deployment without broken paths.
- **Real On-Site Media**: 30 authentic job photos and 4 live site videos showcasing actual waterproofing treatments across Tricity.
- **Local SEO & Schema.org**: Fully integrated `LocalBusiness` JSON-LD structured data for Google local search ranking.
- **Fast WhatsApp & Direct Calling**: Instant click-to-call and pre-filled WhatsApp inquiry forms.
- **Interactive Experience**: Accessible FAQ accordion, verified customer testimonial slider, and collapsible photo archive.

## 📁 Repository Structure (Root Folder)
```
├── index.html                   # Main production website single-page application
├── script.js                    # Production optimized JavaScript (sliders, mobile drawer, faq, validation)
├── styles.css                   # Custom theme styles & utility animations
├── hero.jpg                     # Hero section main image
├── about.jpg                    # About section owner & technician photo
├── service_*.jpg                # Individual service cards (basement, roof, wall, tile epoxy, pool, grouting, etc.)
├── customer_*.jpg               # Verified local customer review avatars
├── cta_trust.jpg                # 10-Year warranty inspection guarantee banner
├── photo_01.jpg .. photo_32.jpg # 30 Authentic on-site project portfolio photos (photo_02 and photo_10 excluded)
├── video_1.mp4 .. video_4_web.mp4 # 4 Real on-site work demonstration videos
├── video_*_thumb.jpg            # Video poster thumbnails
└── README.md                    # Project documentation
```

## 🛠️ GitHub Pages Deployment
1. Initialize git and commit:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of Sarfaraz Ahmad Waterproofing website"
   ```
2. Link your remote repository and push:
   ```bash
   git branch -M main
   git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO_NAME>.git
   git push -u origin main
   ```
3. Enable **GitHub Pages**:
   - Go to repository **Settings** -> **Pages**.
   - Under **Build and deployment** -> **Source**, select **Deploy from a branch**.
   - Select Branch: `main` and Folder: `/ (root)`, then click **Save**.
   - Your website will be live in 1-2 minutes!

---
Designed & Developed by [Truegridleaf.com](https://truegridleaf.com)
